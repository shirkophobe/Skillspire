name = "James Browne"

print(name.count("Browne"))
print( name.endswith("Browne"))
print( "Browne" in name )