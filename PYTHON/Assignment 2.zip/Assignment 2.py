#Create a list containing 10 elements. Print out the last 5 elements of that list.

a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

print(a[5:])

#Using the same list. Print out all the elements between index 3 and 10.

print(a[2:10])
