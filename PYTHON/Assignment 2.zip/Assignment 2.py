username = "browne1970"

print( username.isalnum() )