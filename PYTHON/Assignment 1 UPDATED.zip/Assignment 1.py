name = "James Browne"

print(name.count("Browne"))
print( name.endswith("Browne"))
print( "Browne" in name )

username = "browne1970"

print( username.isalnum() )